﻿using System;
using BazaPracownikowAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace BazaPracownikowAPI.Data
{
    // klasa AppDbContext dziedziczy po klasie bazowej DbContext i komunikuje nas z bazą danych
    public class AppDbContext : DbContext
    {
        //Konstruktor - przyjmuje konfigurację połączenia z bazą danych (DbContextOptions<AppDbContext>) i przekazuje ją do klasy bazowej
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        // Tworzymy bazę danych Tabela Pracownikow na podstawie klasy Models>Pracownik.cs, odpowiadającą bazie sql
        public DbSet<Pracownik> TabelaPracownikow { get; set; }

        // Konfigurujemy szczegóły modelu danych
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Określamy precyzję i skalę dla WynagrodzenieBrutto
            modelBuilder.Entity<Pracownik>()
                .Property(p => p.WynagrodzenieBrutto)
                .HasColumnType("decimal(10,2)"); // Precyzja 10, skala 2
        }
    }
}